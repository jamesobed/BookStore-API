import { match } from "assert";
import { Request, Response, NextFunction } from "express";
import { v4 as uuidv4 } from "uuid";
import bookInstance from "../model/book";
// import UserInstance from "../model/user";
import { createbookSchema, options, updatebookSchema } from "../utils/utils";

// class APIFeatures {
//   mQuery: unknown;
//   eQuery: unknown;
//   constructor(mQuery: unknown, eQuery: unknown) {
//     this.mQuery = mQuery;
//     this.eQuery = eQuery;
//   }
//   myfilter() {
//     const queryObj = { ...this.eQuery };
//     const excludedFields = ["page", "sort", "limit", "fields"];
//     excludedFields.forEach((el) => delete queryObj[el]);
//     let queryStr = JSON.stringify(queryObj);
//     queryStr = queryStr.replace(/\b(gte|gt|lte|lt)\b/g, (match) => `$${match}`);

//     this.mQuery.find(JSON.parse(queryStr));
//   }
// }
export async function createbook(
  req: Request | any,
  res: Response,
  next: NextFunction
) {
  try {
    // const verified = req.user;
    const { title, description, image, price } = req.body;

    const validationResult = createbookSchema.validate(req.body, options);
    if (validationResult.error) {
      return res.status(400).json({
        Error: validationResult.error.details[0].message,
      });
    }
    // const record = await bookInstance.create({
    //   id,
    //   ...req.body,
    //   userId: verified.id,
    // });

    // res.render("createrefresh");

    const newBook = new bookInstance(req.body);
    const book = newBook.save().then((record) => res.status(201).json(record));
  } catch (err) {
    res.status(500).json({
      msg: "failed to create",
      route: "/create",
    });
  }
}
export async function get5CheapBook(
  req: Request,
  res: Response,
  next: NextFunction
) {
  req.query.limit = "5";
  req.query.sort = "price,title";
  req.query.fields = "title,image,price,userId";

  next();
}

export async function getbook(req: Request, res: Response, next: NextFunction) {
  try {
    // console.log(req.query);

    const queryObj = { ...req.query };
    const excludedFields = ["page", "sort", "limit", "fields"];
    excludedFields.forEach((el) => delete queryObj[el]);

    let queryStr = JSON.stringify(queryObj);
    queryStr = queryStr.replace(/\b(gte|gt|lte|lt)\b/g, (match) => `$${match}`);
    // console.log("querry....", JSON.parse(queryStr));

    let myQuery = bookInstance.find(JSON.parse(queryStr));

    //localhost:3019/book/api?sort=title,description,price
    if (req.query.sort) {
      const arrangeSort = req.query.sort.split(",").join(" ");
      myQuery = myQuery.sort(arrangeSort);
    } else {
      myQuery = myQuery.sort("title");
    }

    // localhost:3019/book/api?fields=title,description,price,-_id
    if (req.query.fields) {
      const fields = req.query.fields.split(",").join(" ");
      myQuery = myQuery.select(fields);
    } else {
      myQuery = myQuery.select("-_v");
    }

    const page = req.query.page * 1 || 1;
    const limit = req.query.limit * 1 || 100;
    const skip = (page - 1) * limit;
    myQuery = myQuery.skip(skip).limit(limit);

    if (req.query.page) {
      const numberOfBooks = await bookInstance.countDocuments();
      if (skip >= numberOfBooks) throw new Error("This page does not exist");
    }

    const record = await myQuery;
    return res
      .status(200)
      .json({ msg: "you have successfully fetched all books", record });
    // return res.render("index", { record });
  } catch (error) {
    res.status(404).json({
      msg: "failed to read, Book does not exist",
      route: "/read",
      error: error,
    });
  }
}

export async function getSinglebook(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const { id } = req.params;
    // const record = await bookInstance.findOne({ _id: id });
    const record = await bookInstance.findById(id);

    record
      ? res
          .status(200)
          .json({ msg: "you have successfully fetched all books", record })
      : res.status(400).json({ msg: "No book with this ID" });
    // return res.render("updatebook", { record });
  } catch (error) {
    res.status(500).json({
      msg: "failed to read single book",
      route: "/read/:id",
    });
  }
}

export async function getDeleteSinglebook(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const { id } = req.params;
    console.log(id);

    await bookInstance.findByIdAndDelete(id);
    return res.status(200).json({ msg: "deleted a book successfully" });
    // return res.render("deletebook", { record });
  } catch (error) {
    res.status(500).json({
      msg: "failed to delete a single book",
      route: "/read/:id",
    });
  }
}

export async function updatebook(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const { id } = req.params;
    const { title, description, image, price } = req.body;
    const validationResult = updatebookSchema.validate(req.body, options);
    if (validationResult.error) {
      return res.status(400).json({
        Error: validationResult.error.details[0].message,
      });
    }

    const updatedrecord = await bookInstance.findByIdAndUpdate(id, req.body, {
      new: true,
      runValidators: true,
    });

    return res
      .status(202)
      .json({ msg: "you have successfully updated a book" });
    // return res.render("updaterefresh");
  } catch (error) {
    res.status(500).json({
      msg: "failed to update",
      route: "/update/:id",
    });
  }
}
