// import { DataTypes, Model } from "sequelize";
// import db from "../config/database.config";
// import { bookInstance } from "./book";
import mongoose, { Document, Schema } from "mongoose";
export interface UsersAttributes extends Document {
  firstname: string;
  lastname: string;
  email: string;
  phonenumber: string;
  address: string;
  password: string;
}

// export class UserInstance extends Model<UsersAttributes> {}

const UserInstance = new Schema(
  {
    firstname: {
      type: String,
      required: true,
    },
    lastname: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    phonenumber: {
      type: String,
      required: true,
      unique: true,
    },
    address: {
      type: String,
      required: true,
      unique: false,
    },
    password: {
      type: String,
      required: true,
      select: false,
    },
  },
  {
    timestamps: true,
  }
);

export default mongoose.model<UsersAttributes>("Author", UserInstance);
export const Author = mongoose.model<UsersAttributes>("Author", UserInstance);

// UserInstance.hasMany(bookInstance, { foreignKey: "userId", as: "book" });

// bookInstance.belongsTo(UserInstance, { foreignKey: "userId", as: "user" });
