// import { DataTypes, Model } from "sequelize";
// import db from "../config/database.config";

import mongoose, { Schema } from "mongoose";
export interface bookAttributes {
  title: string;
  description: string;
  image: string;
  price: number;
  userId: string;
}

// export class bookInstance extends Model<bookAttributes> {}

const bookInstance = new Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
      required: true,
      trim: true,
    },
    image: {
      type: String,
      required: true,
      trim: true,
    },
    price: {
      type: Number,
      required: true,
      trim: true,
    },

    userId: {
      type: String,
      required: true,
      trim: true,
    },
  },
  {
    timestamps: true,
  }
);

export default mongoose.model<bookAttributes>("Book", bookInstance);


// export default mongoose.model("Book", bookInstance)
