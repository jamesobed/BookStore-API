import express from "express";
import { auth } from "../middleware/auth";

const router = express.Router();

import {
  createbook,
  getbook,
  getSinglebook,
  getDeleteSinglebook,
  updatebook,
  get5CheapBook,
} from "../controller/bookController";

router.route("/api/top-5-cheapest-book").get(get5CheapBook, getbook);
router
  .route("/api/:id")
  .delete(getDeleteSinglebook)
  .put(updatebook)
  .get(getSinglebook);

router.route("/api/").post(createbook).get(getbook);

export default router;
