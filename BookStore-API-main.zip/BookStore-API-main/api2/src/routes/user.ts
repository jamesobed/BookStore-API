import express from "express";
const router = express.Router();
import {
  RegisterUser,
  LoginUser,
  LogoutUser,
  getUsers,
  defaultView,
} from "../controller/userController";

// router.get("/login", (req, res) => {
//   res.render("login");
// });
// router.get("/addnew", (req, res) => {
//   res.render("newbook");
// });
// router.get("/updatebook", (req, res) => {
//   res.render("updatebook");
// });
// router.get("/editbook", (req, res) => {
//   res.render("editbook");
// });

router.get("/api/dashboard", defaultView);

router.post("/api/login", LoginUser);
router.get("/api/logout", LogoutUser);

router.route("/api").get(getUsers).post(RegisterUser);

export default router;
